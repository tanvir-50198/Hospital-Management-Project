﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Doctor : Form
    {
       
        public DataAccess Da { get; set; }

        public Doctor()
        {
            InitializeComponent();
            this.Da = new DataAccess();

           
            cmbDoctorMale.CheckedChanged += cmbDoctorMale_CheckedChanged;
            cmbDoctorFemale.CheckedChanged += cmbDoctorFemale_CheckedChanged;

            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            doctordataGridView.CellClick += doctorDataGridView_CellClick;

            LoadDoctors();
        }

        private void cmbDoctorMale_CheckedChanged(object sender, EventArgs e)
        {
            try { if (cmbDoctorMale.Checked) cmbDoctorFemale.Checked = false; }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void cmbDoctorFemale_CheckedChanged(object sender, EventArgs e)
        {
            try { if (cmbDoctorFemale.Checked) cmbDoctorMale.Checked = false; }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void LoadDoctors(string sql = "SELECT * FROM Doctorinfo2;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                doctordataGridView.AutoGenerateColumns = true;
                doctordataGridView.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private string GetSelectedGender()
        {
            if (cmbDoctorMale.Checked) return "Male";
            else if (cmbDoctorFemale.Checked) return "Female";
            else return "";
        }

        private void ClearGenderCheckboxes()
        {
            cmbDoctorMale.Checked = false;
            cmbDoctorFemale.Checked = false;
        }

        private void ClearFields()
        {
            txtDoctorName.Clear();
            txtDoctorAge.Clear();
            txtDoctorSpeciality.Clear();
            txtDoctorPhoneNumber.Clear();
            txtDoctorSchedule.Clear();
            ClearGenderCheckboxes();
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtDoctorName.Text) ||
                string.IsNullOrWhiteSpace(txtDoctorAge.Text) ||
                string.IsNullOrWhiteSpace(txtDoctorSpeciality.Text) ||
                string.IsNullOrWhiteSpace(txtDoctorPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(txtDoctorSchedule.Text) ||
                string.IsNullOrEmpty(GetSelectedGender()))
            {
                 MessageBox.Show("Please fill all fields and select gender.");
                return false;
               
            }

            if (!int.TryParse(txtDoctorAge.Text, out int age) || age <= 0)
            {
                MessageBox.Show("Enter a valid age.");
                return false;
            }

            return true;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs()) return;

                string sql = "INSERT INTO Doctorinfo2 (Name, Age, Gender, Speciality, PhoneNumber, Schedule) " +
                             "VALUES (@Name, @Age, @Gender, @Speciality, @Phone, @Schedule)";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Name", txtDoctorName.Text.Trim()),
                    new SqlParameter("@Age", int.Parse(txtDoctorAge.Text.Trim())),
                    new SqlParameter("@Gender", GetSelectedGender()),
                    new SqlParameter("@Speciality", txtDoctorSpeciality.Text.Trim()),
                    new SqlParameter("@Phone", txtDoctorPhoneNumber.Text.Trim()),
                    new SqlParameter("@Schedule", txtDoctorSchedule.Text.Trim())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Doctor added successfully!");
                    LoadDoctors();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Insert failed.");
                }
            }
            catch (Exception ex) { MessageBox.Show("Insert error: " + ex.Message); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (doctordataGridView.CurrentRow == null || doctordataGridView.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a doctor to update.");
                    return;
                }

                if (!ValidateInputs()) return;

                string id = doctordataGridView.CurrentRow.Cells[0].Value.ToString();

                string sql = "UPDATE Doctorinfo2 SET Name=@Name, Age=@Age, Gender=@Gender, Speciality=@Speciality, " +
                             "PhoneNumber=@Phone, Schedule=@Schedule WHERE DoctorID=@Id";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Name", txtDoctorName.Text.Trim()),
                    new SqlParameter("@Age", int.Parse(txtDoctorAge.Text.Trim())),
                    new SqlParameter("@Gender", GetSelectedGender()),
                    new SqlParameter("@Speciality", txtDoctorSpeciality.Text.Trim()),
                    new SqlParameter("@Phone", txtDoctorPhoneNumber.Text.Trim()),
                    new SqlParameter("@Schedule", txtDoctorSchedule.Text.Trim()),
                    new SqlParameter("@Id", int.Parse(id))
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Doctor updated successfully!");
                    LoadDoctors();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Update failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (doctordataGridView.CurrentRow == null || doctordataGridView.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a doctor to delete.");
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure you want to delete this doctor?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirm != DialogResult.Yes) return;

                string id = doctordataGridView.CurrentRow.Cells[0].Value.ToString();

                string sql = "DELETE FROM Doctorinfo2 WHERE DoctorID=@DoctorID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@DoctorID", int.Parse(id))
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Doctor deleted successfully!");
                    LoadDoctors();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Delete failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error: " + ex.Message);
            }
        }

        private void doctorDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = doctordataGridView.Rows[e.RowIndex];
                txtDoctorName.Text = row.Cells[1].Value.ToString();
                txtDoctorAge.Text = row.Cells[2].Value.ToString();
                string gender = row.Cells[3].Value.ToString();
                cmbDoctorMale.Checked = gender == "Male";
                cmbDoctorFemale.Checked = gender == "Female";
                txtDoctorSpeciality.Text = row.Cells[4].Value.ToString();
                txtDoctorPhoneNumber.Text = row.Cells[5].Value.ToString();
                txtDoctorSchedule.Text = row.Cells[6].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select error: " + ex.Message);
            }
        }

       
    }
}