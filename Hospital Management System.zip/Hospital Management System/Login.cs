﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Login : Form
    {
        public DataAccess Da { get; set; }

        public Login()
        {
            InitializeComponent();
            this.Da = new DataAccess(); 
        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM Userinfo WHERE UserID = @UserID AND Password = @Password;";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", txtUserId.Text.Trim()),
                new SqlParameter("@Password", txtPassword.Text.Trim())
            };

            try
            {
                DataSet ds = this.Da.ExecuteQuery(sql, parameters);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    string role = ds.Tables[0].Rows[0]["Role"].ToString().ToLower();

                    if (role == "admin")
                    {
                        MessageBox.Show("Valid User: Admin");
                        new Form2(this).Show();
                    }
                    else if (role == "receptionist")
                    {
                        MessageBox.Show("Valid User: Receptionist");
                        new Receptionist(this).Show();
                    }
                    else
                    {
                        MessageBox.Show("Unknown role");
                    }

                    txtUserId.Clear();
                    txtPassword.Clear();
                }
                else
                {
                    MessageBox.Show("Invalid User ID or Password");
                    txtUserId.Clear();
                    txtPassword.Clear();
                    txtUserId.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtUserId.Clear();
            txtPassword.Clear();
            txtUserId.Focus();
        }

        private void chkShowPassword_CheckedChanged_1(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = true;
        }
    }
}
