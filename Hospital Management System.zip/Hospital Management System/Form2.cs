﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class Form2 : Form
    {
        private Login login;  
        public Form2()
        {
            InitializeComponent();

        }

        public Form2(Login login)  
        {
            InitializeComponent();
            this.login = login;
        }
        private void btnPatient_Click(object sender, EventArgs e)
        {
            
            Patient patient = new Patient();
            patient.Visible = true;

        }

        private void bntDoctor_Click(object sender, EventArgs e)
        {
            
            Doctor doctor = new Doctor();
            doctor.Visible = true;
        }

        private void bntNurse_Click(object sender, EventArgs e)
        {
            Nurse nurse = new Nurse();
            nurse.Visible = true;
        }

        private void bntAppointment_Click(object sender, EventArgs e)
        {
            Appointment appointment = new Appointment();
            appointment.Visible = true;
        }

        private void bntMedicalRecord_Click(object sender, EventArgs e)
        {
            MedicalRecord medicalRecord = new MedicalRecord();
            medicalRecord.Visible = true;
        }

        private void bntBill_Click(object sender, EventArgs e)
        {
            Bill bill = new Bill();
            bill.Visible = true;
        }

        private void bntDashbuard_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Visible = true;
        }

      

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnReceptionist_Click(object sender, EventArgs e)
        {
            UserInfo userinfo = new UserInfo();
            userinfo.Visible = true;
        }

        private void btnAdminLogOut_Click(object sender, EventArgs e)
        {
            this.login.Visible = true;
            this.Hide();
        }
    }
}
