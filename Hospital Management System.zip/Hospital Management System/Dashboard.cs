﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Dashboard : Form
    {
        public DataAccess Da { get; set; }

        public Dashboard()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            LoadDashboardStats();
        }

        private void LoadDashboardStats()
        {
            try
            {
                
                string sqlPatient = "SELECT COUNT(*) FROM Patient";
                lblTotalPatients.Text = GetCount(sqlPatient).ToString();

                
                string sqlDoctor = "SELECT COUNT(*) FROM Doctorinfo2";
                lblTotalDoctors.Text = GetCount(sqlDoctor).ToString();

                string sqlNurse = "SELECT COUNT(*) FROM Nurse";
                lblTotalNurses.Text = GetCount(sqlNurse).ToString();

                
            
                string sqlAppointment = "SELECT COUNT(*) FROM Appointment";
                lblTotalAppointments.Text = GetCount(sqlAppointment).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Dashboard load error: " + ex.Message);
            }
        }

        private int GetCount(string query)
        {
            try
            {
                var ds = this.Da.ExecuteQuery(query);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    return Convert.ToInt32(ds.Tables[0].Rows[0][0]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Count error: " + ex.Message);
            }
            return 0;
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
