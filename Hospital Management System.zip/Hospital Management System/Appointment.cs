﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Appointment : Form
    {
        public DataAccess Da { get; set; }

        public Appointment()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            btnPatientSearch.Click += btnPatientSearch_Click;
            btnDoctorSearch.Click += btnDoctorSearch_Click;
            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            AppointmentdataGridView.CellClick += AppointmentdataGridView_CellClick;

            LoadAppointments();
        }

        private void LoadAppointments(string sql = "SELECT * FROM Appointment")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                AppointmentdataGridView.AutoGenerateColumns = true;
                AppointmentdataGridView.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtPatientName.Text) ||
                string.IsNullOrWhiteSpace(txtDoctorNumber.Text) ||
                string.IsNullOrWhiteSpace(txtTime.Text) ||
                string.IsNullOrWhiteSpace(txtStatus.Text))
            {
                MessageBox.Show("Please fill all fields.");
                return false;
            }
            return true;
        }

        private bool IsPatientExists(string phone)
        {
            string sql = "SELECT COUNT(*) FROM Patient WHERE PhoneNumber = @Phone";
            var ds = this.Da.ExecuteQuery(sql, new SqlParameter[] {
                new SqlParameter("@Phone", phone)
            });
            return Convert.ToInt32(ds.Tables[0].Rows[0][0]) > 0;
        }

        private bool IsDoctorExists(string phone)
        {
            string sql = "SELECT COUNT(*) FROM Doctorinfo2 WHERE PhoneNumber = @Phone";
            var ds = this.Da.ExecuteQuery(sql, new SqlParameter[] {
                new SqlParameter("@Phone", phone)
            });
            return Convert.ToInt32(ds.Tables[0].Rows[0][0]) > 0;
        }

        private void btnPatientSearch_Click(object sender, EventArgs e)
        {
            string phone = txtPatientName.Text.Trim();
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Enter patient number to search.");
                return;
            }

            if (IsPatientExists(phone))
                MessageBox.Show("Patient found.");
            else
                MessageBox.Show("No patient found.");
        }

        private void btnDoctorSearch_Click(object sender, EventArgs e)
        {
            string phone = txtDoctorNumber.Text.Trim();
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Enter doctor number to search.");
                return;
            }

            if (IsDoctorExists(phone))
                MessageBox.Show("Doctor found.");
            else
                MessageBox.Show("No doctor found.");
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            string patient = txtPatientName.Text.Trim();
            string doctor = txtDoctorNumber.Text.Trim();

            if (!IsPatientExists(patient))
            {
                MessageBox.Show("Patient not found. Cannot insert.");
                return;
            }

            if (!IsDoctorExists(doctor))
            {
                MessageBox.Show("Doctor not found. Cannot insert.");
                return;
            }

            string sql = @"INSERT INTO Appointment (PatientNumber, DoctorNumber, Date, Time, Status) 
                           VALUES (@Patient, @Doctor, @Date, @Time, @Status)";
            SqlParameter[] param = {
                new SqlParameter("@Patient", patient),
                new SqlParameter("@Doctor", doctor),
                new SqlParameter("@Date", dtpDate.Value),
                new SqlParameter("@Time", txtTime.Text.Trim()),
                new SqlParameter("@Status", txtStatus.Text.Trim())
            };

            int result = this.Da.ExecuteUpdateQuery(sql, param);
            if (result > 0)
            {
                MessageBox.Show("Inserted successfully.");
                LoadAppointments();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Insert failed.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (AppointmentdataGridView.CurrentRow == null || AppointmentdataGridView.CurrentRow.Cells[0].Value == null)
            {
                MessageBox.Show("Select an appointment to update.");
                return;
            }

            if (!ValidateInputs()) return;

            string id = AppointmentdataGridView.CurrentRow.Cells[0].Value.ToString();

            string sql = @"UPDATE Appointment SET 
                            PatientNumber = @Patient, 
                            DoctorNumber = @Doctor, 
                            Date = @Date, 
                            Time = @Time, 
                            Status = @Status
                           WHERE AppointmentID = @Id";

            SqlParameter[] param = {
                new SqlParameter("@Patient", txtPatientName.Text.Trim()),
                new SqlParameter("@Doctor", txtDoctorNumber.Text.Trim()),
                new SqlParameter("@Date", dtpDate.Value),
                new SqlParameter("@Time", txtTime.Text.Trim()),
                new SqlParameter("@Status", txtStatus.Text.Trim()),
                new SqlParameter("@Id", Convert.ToInt32(id))
            };

            int result = this.Da.ExecuteUpdateQuery(sql, param);
            if (result > 0)
            {
                MessageBox.Show("Updated successfully.");
                LoadAppointments();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Update failed.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (AppointmentdataGridView.CurrentRow == null || AppointmentdataGridView.CurrentRow.Cells[0].Value == null)
            {
                MessageBox.Show("Select an appointment to delete.");
                return;
            }

            DialogResult confirm = MessageBox.Show("Delete this appointment?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;

            string id = AppointmentdataGridView.CurrentRow.Cells[0].Value.ToString();
            string sql = "DELETE FROM Appointment WHERE AppointmentID = @Id";
            SqlParameter[] param = { new SqlParameter("@Id", Convert.ToInt32(id)) };

            int result = this.Da.ExecuteUpdateQuery(sql, param);
            if (result > 0)
            {
                MessageBox.Show("Deleted successfully.");
                LoadAppointments();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Delete failed.");
            }
        }

        private void AppointmentdataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.RowIndex < AppointmentdataGridView.Rows.Count)
                {
                    DataGridViewRow row = AppointmentdataGridView.Rows[e.RowIndex];
                    txtPatientName.Text = row.Cells[1].Value.ToString();
                    txtDoctorNumber.Text = row.Cells[2].Value.ToString();
                    dtpDate.Value = Convert.ToDateTime(row.Cells[3].Value);
                    txtTime.Text = row.Cells[4].Value.ToString();
                    txtStatus.Text = row.Cells[5].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Selection error: " + ex.Message);
            }
        }

        private void ClearFields()
        {
            txtPatientName.Clear();
            txtDoctorNumber.Clear();
            txtTime.Clear();
            txtStatus.Clear();
            dtpDate.Value = DateTime.Now;
        }

        private void Appointment_Load(object sender, EventArgs e)
        {
          
            this.appointmentTableAdapter.Fill(this.hospitalDataSet8.Appointment);
        }

        private void btnPatientSearch_Click_1(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click_1(object sender, EventArgs e)
        {

        }
    }
}
