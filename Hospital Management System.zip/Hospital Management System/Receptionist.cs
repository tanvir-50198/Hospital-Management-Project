﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class Receptionist : Form
    {
        private Login login;
        public Receptionist()
        {
            InitializeComponent();
        }
        public Receptionist(Login login)
        {
            InitializeComponent();
            this.login = login;
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient();
            patient.Visible = true;
        }

        private void bntAppointment_Click(object sender, EventArgs e)
        {
           Appointment appointment = new Appointment();
            appointment.Visible = true;
        }

        private void bntMedicalRecord_Click(object sender, EventArgs e)
        {
            MedicalRecord medicicalRecord = new MedicalRecord();
            medicicalRecord.Visible = true;
        }

        private void bntBill_Click(object sender, EventArgs e)
        {
            Bill bill = new Bill();
            bill.Visible = true;
        }

        private void bntDashboard_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Visible = true;
        }

        private void btnReceptionistLogout_Click(object sender, EventArgs e)
        {
            this.login.Visible = true;
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
