﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class MedicalRecord : Form
    {
        public DataAccess Da { get; set; }

        public MedicalRecord()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            btnPatientSearch.Click += btnPatientSearch_Click;
            btnDoctorSearch.Click += btnDoctorSearch_Click;
            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            MedicalRecorddataGridView.CellClick += MedicalRecorddataGridView_CellClick;

            LoadMedicalRecords();
        }

        private void LoadMedicalRecords(string sql = "SELECT * FROM MedicalRecord")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                MedicalRecorddataGridView.AutoGenerateColumns = true;
                MedicalRecorddataGridView.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtPatientNumber.Text) ||
                string.IsNullOrWhiteSpace(txtDoctorNumber.Text) ||
                string.IsNullOrWhiteSpace(txtDiagnosis.Text) ||
                string.IsNullOrWhiteSpace(txtPrescription.Text) ||
                string.IsNullOrWhiteSpace(txtNote.Text))
            {
                MessageBox.Show("Please fill all fields.");
                return false;
            }
            return true;
        }

        private bool IsPatientExists(string phone)
        {
            string sql = "SELECT COUNT(*) FROM Patient WHERE PhoneNumber = @Phone";
            var ds = this.Da.ExecuteQuery(sql, new SqlParameter[] {
                new SqlParameter("@Phone", phone)
            });
            return Convert.ToInt32(ds.Tables[0].Rows[0][0]) > 0;
        }

        private bool IsDoctorExists(string phone)
        {
            string sql = "SELECT COUNT(*) FROM Doctorinfo2 WHERE PhoneNumber = @Phone";
            var ds = this.Da.ExecuteQuery(sql, new SqlParameter[] {
                new SqlParameter("@Phone", phone)
            });
            return Convert.ToInt32(ds.Tables[0].Rows[0][0]) > 0;
        }

        private void btnPatientSearch_Click(object sender, EventArgs e)
        {
            string phone = txtPatientNumber.Text.Trim();
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Enter patient number to search.");
                return;
            }

            if (IsPatientExists(phone))
                MessageBox.Show("Patient found.");
            else
                MessageBox.Show("No patient found.");
        }

        private void btnDoctorSearch_Click(object sender, EventArgs e)
        {
            string phone = txtDoctorNumber.Text.Trim();
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Enter doctor number to search.");
                return;
            }

            if (IsDoctorExists(phone))
                MessageBox.Show("Doctor found.");
            else
                MessageBox.Show("No doctor found.");
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            string patient = txtPatientNumber.Text.Trim();
            string doctor = txtDoctorNumber.Text.Trim();

            if (!IsPatientExists(patient))
            {
                MessageBox.Show("Patient not found. Cannot insert.");
                return;
            }

            if (!IsDoctorExists(doctor))
            {
                MessageBox.Show("Doctor not found. Cannot insert.");
                return;
            }

            string sql = @"INSERT INTO MedicalRecord (PatientNumber, DoctorNumber, Date, Diagnosis, Prescription, Note) 
                           VALUES (@Patient, @Doctor, @Date, @Diagnosis, @Prescription, @Note)";
            SqlParameter[] param = {
                new SqlParameter("@Patient", patient),
                new SqlParameter("@Doctor", doctor),
                new SqlParameter("@Date", dtpDate.Value),
                new SqlParameter("@Diagnosis", txtDiagnosis.Text.Trim()),
                new SqlParameter("@Prescription", txtPrescription.Text.Trim()),
                new SqlParameter("@Note", txtNote.Text.Trim())
            };

            int result = this.Da.ExecuteUpdateQuery(sql, param);
            if (result > 0)
            {
                MessageBox.Show("Inserted successfully.");
                LoadMedicalRecords();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Insert failed.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (MedicalRecorddataGridView.CurrentRow == null || MedicalRecorddataGridView.CurrentRow.Cells[0].Value == null)
            {
                MessageBox.Show("Select a record to update.");
                return;
            }

            if (!ValidateInputs()) return;

            string id = MedicalRecorddataGridView.CurrentRow.Cells[0].Value.ToString();

            string sql = @"UPDATE MedicalRecord SET 
                            PatientNumber = @Patient, 
                            DoctorNumber = @Doctor, 
                            Date = @Date, 
                            Diagnosis = @Diagnosis, 
                            Prescription = @Prescription, 
                            Note = @Note
                           WHERE MedicalRecordID = @Id";

            SqlParameter[] param = {
                new SqlParameter("@Patient", txtPatientNumber.Text.Trim()),
                new SqlParameter("@Doctor", txtDoctorNumber.Text.Trim()),
                new SqlParameter("@Date", dtpDate.Value),
                new SqlParameter("@Diagnosis", txtDiagnosis.Text.Trim()),
                new SqlParameter("@Prescription", txtPrescription.Text.Trim()),
                new SqlParameter("@Note", txtNote.Text.Trim()),
                new SqlParameter("@Id", Convert.ToInt32(id))
            };

            int result = this.Da.ExecuteUpdateQuery(sql, param);
            if (result > 0)
            {
                MessageBox.Show("Updated successfully.");
                LoadMedicalRecords();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Update failed.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MedicalRecorddataGridView.CurrentRow == null || MedicalRecorddataGridView.CurrentRow.Cells[0].Value == null)
            {
                MessageBox.Show("Select a record to delete.");
                return;
            }

            DialogResult confirm = MessageBox.Show("Delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;

            string id = MedicalRecorddataGridView.CurrentRow.Cells[0].Value.ToString();
            string sql = "DELETE FROM MedicalRecord WHERE MedicalRecordID = @Id";
            SqlParameter[] param = { new SqlParameter("@Id", Convert.ToInt32(id)) };

            int result = this.Da.ExecuteUpdateQuery(sql, param);
            if (result > 0)
            {
                MessageBox.Show("Deleted successfully.");
                LoadMedicalRecords();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Delete failed.");
            }
        }

        private void MedicalRecorddataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.RowIndex < MedicalRecorddataGridView.Rows.Count)
                {
                    DataGridViewRow row = MedicalRecorddataGridView.Rows[e.RowIndex];
                    txtPatientNumber.Text = row.Cells[1].Value.ToString();
                    txtDoctorNumber.Text = row.Cells[2].Value.ToString();
                    dtpDate.Value = Convert.ToDateTime(row.Cells[3].Value);
                    txtDiagnosis.Text = row.Cells[4].Value.ToString();
                    txtPrescription.Text = row.Cells[5].Value.ToString();
                    txtNote.Text = row.Cells[6].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Selection error: " + ex.Message);
            }
        }

        private void ClearFields()
        {
            txtPatientNumber.Clear();
            txtDoctorNumber.Clear();
            txtDiagnosis.Clear();
            txtPrescription.Clear();
            txtNote.Clear();
            dtpDate.Value = DateTime.Now;
        }

        private void MedicalRecord_Load(object sender, EventArgs e)
        {
            
            this.medicalRecordTableAdapter.Fill(this.hospitalDataSet9.MedicalRecord);
           
            this.medicalRecordTableAdapter.Fill(this.hospitalDataSet9.MedicalRecord);
        }

        private void btnPatientSearch_Click_1(object sender, EventArgs e)
        {

        }
    }
}