﻿using System.Data;
using System.Data.SqlClient;

namespace WFACrudQ
{
    public class DataAccess
    {
        private  string connectionString = @"Data Source=LAPTOP-NS45TS53\SQLEXPRESS;Initial Catalog=hospital;User ID=sa;Password=1234";

        // SELECT query (raw SQL, no parameters)
        public DataSet ExecuteQuery(string sql)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlDataAdapter sda = new SqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }

        // SELECT query with parameters
        public DataSet ExecuteQuery(string sql, SqlParameter[] parameters)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddRange(parameters);
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataSet ds = new DataSet();
                        sda.Fill(ds);
                        return ds;
                    }
                }
            }
        }

        // INSERT, UPDATE, DELETE query without parameters/DML
        public int ExecuteUpdateQuery(string sql)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                int count = cmd.ExecuteNonQuery();
                return count;
            }
        }

        // INSERT, UPDATE, DELETE query with parameters
        public int ExecuteUpdateQuery(string sql, SqlParameter[] parameters)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddRange(parameters);
                    con.Open();
                    int count = cmd.ExecuteNonQuery();
                    return count;
                }
            }
        }

        // Optional alias for DML queries
        public int ExecuteDMLQuery(string sql)
        {
            return ExecuteUpdateQuery(sql);
        }

        // Optional alias for DML queries with parameters
        public int ExecuteDMLQuery(string sql, SqlParameter[] parameters)
        {
            return ExecuteUpdateQuery(sql, parameters);
        }
    }
}
