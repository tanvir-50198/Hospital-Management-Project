﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Nurse : Form
    {
        public DataAccess Da { get; set; }

        public Nurse()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            cmbNurseMale.CheckedChanged += cmbNurseMale_CheckedChanged;
            cmbNurseFemale.CheckedChanged += cmbNurseFemale_CheckedChanged;

            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            nursedataGridview.CellClick += nursedataGridView_CellClick;

            LoadNurses();
        }

        private void cmbNurseMale_CheckedChanged(object sender, EventArgs e)
        {
            if (cmbNurseMale.Checked) cmbNurseFemale.Checked = false;
        }

        private void cmbNurseFemale_CheckedChanged(object sender, EventArgs e)
        {
            if (cmbNurseFemale.Checked) cmbNurseMale.Checked = false;
        }

        private void LoadNurses(string sql = "SELECT * FROM Nurse;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                nursedataGridview.AutoGenerateColumns = true;
                nursedataGridview.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private string GetSelectedGender()
        {
            if (cmbNurseMale.Checked) return "Male";
            else if (cmbNurseFemale.Checked) return "Female";
            else return "";
        }

        private void ClearGenderCheckboxes()
        {
            cmbNurseMale.Checked = false;
            cmbNurseFemale.Checked = false;
        }

        private void ClearFields()
        {
            txtNurseName.Clear();
            txtNurseAge.Clear();
            txtNursePhoneNumber.Clear();
            txtNurseShift.Clear();
            ClearGenderCheckboxes();
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtNurseName.Text) ||
                string.IsNullOrWhiteSpace(txtNurseAge.Text) ||
                string.IsNullOrWhiteSpace(txtNursePhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(txtNurseShift.Text) ||
                string.IsNullOrEmpty(GetSelectedGender()))
            {
                MessageBox.Show("Please fill all fields and select gender.");
                return false;
            }

            if (!int.TryParse(txtNurseAge.Text, out int age) || age <= 0)
            {
                MessageBox.Show("Enter a valid age.");
                return false;
            }

            return true;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs()) return;

                string sql = "INSERT INTO Nurse (Name, Age, Gender, PhoneNumber, Shift) VALUES (@Name, @Age, @Gender, @Phone, @Shift)";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Name", txtNurseName.Text.Trim()),
                    new SqlParameter("@Age", int.Parse(txtNurseAge.Text.Trim())),
                    new SqlParameter("@Gender", GetSelectedGender()),
                    new SqlParameter("@Phone", txtNursePhoneNumber.Text.Trim()),
                    new SqlParameter("@Shift", txtNurseShift.Text.Trim())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Nurse added successfully!");
                    LoadNurses();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Insert failed.");
                }
            }
            catch (Exception ex) { MessageBox.Show("Insert error: " + ex.Message); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (nursedataGridview.CurrentRow == null || nursedataGridview.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a nurse to update.");
                    return;
                }

                if (!ValidateInputs()) return;

                string id = nursedataGridview.CurrentRow.Cells[0].Value.ToString();

                string sql = "UPDATE Nurse SET Name=@Name, Age=@Age, Gender=@Gender, PhoneNumber=@Phone, Shift=@Shift WHERE NurseID=@Id";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Name", txtNurseName.Text.Trim()),
                    new SqlParameter("@Age", int.Parse(txtNurseAge.Text.Trim())),
                    new SqlParameter("@Gender", GetSelectedGender()),
                    new SqlParameter("@Phone", txtNursePhoneNumber.Text.Trim()),
                    new SqlParameter("@Shift", txtNurseShift.Text.Trim()),
                    new SqlParameter("@Id", int.Parse(id))
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Nurse updated successfully!");
                    LoadNurses();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Update failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (nursedataGridview.CurrentRow == null || nursedataGridview.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a nurse to delete.");
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure you want to delete this nurse?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirm != DialogResult.Yes) return;

                string id = nursedataGridview.CurrentRow.Cells[0].Value.ToString();
                string sql = "DELETE FROM Nurse WHERE NurseID=@NurseID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@NurseID", int.Parse(id))
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Nurse deleted successfully!");
                    LoadNurses();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Delete failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error: " + ex.Message);
            }
        }

        private void nursedataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = nursedataGridview.Rows[e.RowIndex];
                txtNurseName.Text = row.Cells[1].Value.ToString();
                txtNurseAge.Text = row.Cells[2].Value.ToString();
                string gender = row.Cells[3].Value.ToString();
                cmbNurseMale.Checked = gender == "Male";
                cmbNurseFemale.Checked = gender == "Female";
                txtNursePhoneNumber.Text = row.Cells[4].Value.ToString();
                txtNurseShift.Text = row.Cells[5].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select error: " + ex.Message);
            }
        }
    }
}
