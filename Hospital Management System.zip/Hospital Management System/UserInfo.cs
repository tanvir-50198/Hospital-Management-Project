﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class UserInfo : Form
    {
        public DataAccess Da { get; set; }

        public UserInfo()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            // Event bindings
            cmbAdmin.CheckedChanged += cmbAdmin_CheckedChanged;
            cmbReceptionist.CheckedChanged += cmbReceptionist_CheckedChanged;

            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            UserInfodataGridView.CellClick += UserInfodataGridView_CellClick;

            LoadUsers();
        }

        private void cmbAdmin_CheckedChanged(object sender, EventArgs e)
        {
            if (cmbAdmin.Checked) cmbReceptionist.Checked = false;
        }

        private void cmbReceptionist_CheckedChanged(object sender, EventArgs e)
        {
            if (cmbReceptionist.Checked) cmbAdmin.Checked = false;
        }

        private string GetSelectedRole()
        {
            if (cmbAdmin.Checked) return "Admin";
            else if (cmbReceptionist.Checked) return "Receptionist";
            else return "";
        }

        private void ClearRoleSelection()
        {
            cmbAdmin.Checked = false;
            cmbReceptionist.Checked = false;
        }

        private void ClearFields()
        {
            txtUserID.Clear();
            txtUserName.Clear();
            txtUserPassword.Clear();
            ClearRoleSelection();
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtUserID.Text) ||
                string.IsNullOrWhiteSpace(txtUserName.Text) ||
                string.IsNullOrWhiteSpace(txtUserPassword.Text) ||
                string.IsNullOrEmpty(GetSelectedRole()))
            {
                MessageBox.Show("Please fill all fields and select a role.");
                return false;
            }

            return true;
        }

        private void LoadUsers(string query = "SELECT * FROM UserInfo;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(query);
                UserInfodataGridView.AutoGenerateColumns = true;
                UserInfodataGridView.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load Error: " + ex.Message);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs()) return;

                string sql = "INSERT INTO UserInfo (UserID, Username, Password, Role) " +
                             "VALUES (@UserID, @Username, @Password, @Role)";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@UserID", txtUserID.Text.Trim()),
                    new SqlParameter("@Username", txtUserName.Text.Trim()),
                    new SqlParameter("@Password", txtUserPassword.Text.Trim()),
                    new SqlParameter("@Role", GetSelectedRole())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("User inserted successfully!");
                    LoadUsers();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Insert failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert error: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs()) return;

                string sql = "UPDATE UserInfo SET Username=@Username, Password=@Password, Role=@Role " +
                             "WHERE UserID=@UserID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Username", txtUserName.Text.Trim()),
                    new SqlParameter("@Password", txtUserPassword.Text.Trim()),
                    new SqlParameter("@Role", GetSelectedRole()),
                    new SqlParameter("@UserID", txtUserID.Text.Trim())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("User updated successfully!");
                    LoadUsers();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Update failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtUserID.Text))
                {
                    MessageBox.Show("Please enter UserID to delete.");
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (confirm != DialogResult.Yes) return;

                string sql = "DELETE FROM UserInfo WHERE UserID=@UserID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@UserID", txtUserID.Text.Trim())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("User deleted successfully!");
                    LoadUsers();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Delete failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error: " + ex.Message);
            }
        }

        private void UserInfodataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = UserInfodataGridView.Rows[e.RowIndex];
                txtUserID.Text = row.Cells[0].Value.ToString();
                txtUserName.Text = row.Cells[1].Value.ToString();
                txtUserPassword.Text = row.Cells[2].Value.ToString();
                string role = row.Cells[3].Value.ToString();

                cmbAdmin.Checked = role == "Admin";
                cmbReceptionist.Checked = role == "Receptionist";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Selection error: " + ex.Message);
            }
        }
    }
}
