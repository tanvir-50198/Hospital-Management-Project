﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Bill : Form
    {
        public DataAccess Da { get; set; }

        public Bill()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            btnSearch.Click += btnSearch_Click;
            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            BilldataGridView.CellClick += BilldataGridView_CellClick;

            LoadBills();
        }

        private void LoadBills(string sql = "SELECT * FROM Bill")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                BilldataGridView.AutoGenerateColumns = true;
                BilldataGridView.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(txtAmount.Text) ||
                string.IsNullOrWhiteSpace(txtStatus.Text))
            {
                MessageBox.Show("Please fill all fields.");
                return false;
            }

            if (!long.TryParse(txtAmount.Text.Trim(), out _))
            {
                MessageBox.Show("Amount must be a valid whole number.");
                return false;
            }

            return true;
        }

        private bool IsPatientPhoneExists(string phone)
        {
            try
            {
                string sql = "SELECT COUNT(*) FROM Patient WHERE PhoneNumber = @Phone";
                SqlParameter[] param = { new SqlParameter("@Phone", phone) };
                var ds = this.Da.ExecuteQuery(sql, param);
                return Convert.ToInt32(ds.Tables[0].Rows[0][0]) > 0;
            }
            catch
            {
                return false;
            }
        }

        private void ClearFields()
        {
            txtPhoneNumber.Clear();
            txtAmount.Clear();
            txtStatus.Clear();
            dtpDate.Value = DateTime.Now;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string phone = txtPhoneNumber.Text.Trim();
            if (string.IsNullOrEmpty(phone))
            {
                MessageBox.Show("Enter patient phone number to search.");
                return;
            }

            string sql = "SELECT * FROM Patient WHERE PhoneNumber = @Phone";
            SqlParameter[] param = { new SqlParameter("@Phone", phone) };
            var ds = this.Da.ExecuteQuery(sql, param);
            BilldataGridView.AutoGenerateColumns = true;
            BilldataGridView.DataSource = ds.Tables[0];

            if (ds.Tables[0].Rows.Count == 0)
                MessageBox.Show("No Patient found for this phone number.");
            else
                MessageBox.Show(" Found Patient for this phone number.");
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs()) return;

                string phone = txtPhoneNumber.Text.Trim();
                if (!IsPatientPhoneExists(phone))
                {
                    MessageBox.Show("Patient not found. Cannot insert bill.");
                    return;
                }

                string sql = "INSERT INTO Bill (PatientPhoneNumber, Amount, Date, Status) " +
                             "VALUES (@Phone, @Amount, @Date, @Status)";
                SqlParameter[] param = {
                    new SqlParameter("@Phone", phone),
                    new SqlParameter("@Amount", Convert.ToInt64(txtAmount.Text.Trim())),
                    new SqlParameter("@Date", dtpDate.Value),
                    new SqlParameter("@Status", txtStatus.Text.Trim())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, param);
                if (result > 0)
                {
                    MessageBox.Show("Bill inserted successfully.");
                    LoadBills();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Insert failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Insert error: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (BilldataGridView.CurrentRow == null || BilldataGridView.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a bill to update.");
                    return;
                }

                if (!ValidateInputs()) return;

                string phone = txtPhoneNumber.Text.Trim();
                if (!IsPatientPhoneExists(phone))
                {
                    MessageBox.Show("Patient not found. Cannot update bill.");
                    return;
                }

                string id = BilldataGridView.CurrentRow.Cells[0].Value.ToString();

                string sql = "UPDATE Bill SET PatientPhoneNumber=@Phone, Amount=@Amount, Date=@Date, Status=@Status " +
                             "WHERE BillID=@Id";
                SqlParameter[] param = {
                    new SqlParameter("@Phone", phone),
                    new SqlParameter("@Amount", Convert.ToInt64(txtAmount.Text.Trim())),
                    new SqlParameter("@Date", dtpDate.Value),
                    new SqlParameter("@Status", txtStatus.Text.Trim()),
                    new SqlParameter("@Id", int.Parse(id))
                };

                int result = this.Da.ExecuteUpdateQuery(sql, param);
                if (result > 0)
                {
                    MessageBox.Show("Bill updated successfully.");
                    LoadBills();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Update failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (BilldataGridView.CurrentRow == null || BilldataGridView.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a bill to delete.");
                    return;
                }

                DialogResult confirm = MessageBox.Show("Are you sure to delete this bill?", "Confirm Delete", MessageBoxButtons.YesNo);
                if (confirm != DialogResult.Yes) return;

                string id = BilldataGridView.CurrentRow.Cells[0].Value.ToString();
                string sql = "DELETE FROM Bill WHERE BillID=@Id";
                SqlParameter[] param = { new SqlParameter("@Id", int.Parse(id)) };

                int result = this.Da.ExecuteUpdateQuery(sql, param);
                if (result > 0)
                {
                    MessageBox.Show("Bill deleted successfully.");
                    LoadBills();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Delete failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete error: " + ex.Message);
            }
        }

        private void BilldataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.RowIndex < BilldataGridView.Rows.Count)
                {
                    DataGridViewRow row = BilldataGridView.Rows[e.RowIndex];
                    txtPhoneNumber.Text = row.Cells[1].Value.ToString();
                    txtAmount.Text = row.Cells["Amount"].Value.ToString();
                    dtpDate.Value = Convert.ToDateTime(row.Cells[3].Value);
                    txtStatus.Text = row.Cells[4].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Selection error: " + ex.Message);
            }
        }

        private void Bill_Load(object sender, EventArgs e)
        {
            
            this.billTableAdapter1.Fill(this.hospitalDataSet6.Bill);

        }

        private void btnInsert_Click_1(object sender, EventArgs e)
        {

        }
    }
}
