﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using WFACrudQ;

namespace Hospital_Management_System
{
    public partial class Patient : Form
    {
       
        public DataAccess Da { get; set; }
        
        public Patient()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            // Attach events
            cmbPatientMale.CheckedChanged += cmbPatientMale_CheckedChanged;
            cmbPatientFemale.CheckedChanged += cmbPatientFemale_CheckedChanged;

            btnInsert.Click += btnInsert_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
          

            PatientGridView.CellClick += PatientGridView_CellClick;

            LoadPatients();
        }

        private void cmbPatientMale_CheckedChanged(object sender, EventArgs e)
        {
            try { if (cmbPatientMale.Checked) cmbPatientFemale.Checked = false; }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        private void cmbPatientFemale_CheckedChanged(object sender, EventArgs e)
        {
            try { if (cmbPatientFemale.Checked) cmbPatientMale.Checked = false; }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }
        //The purpose of the LoadPatients() method is to read all data from the Patient table in the database and display it in the GridView
        private void LoadPatients(string sql = "SELECT * FROM Patient;")
        {
            try
            {
                var ds = this.Da.ExecuteQuery(sql);
                PatientGridView.AutoGenerateColumns = true;
                PatientGridView.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load error: " + ex.Message);
            }
        }

        private string GetSelectedGender()
        {
            if (cmbPatientMale.Checked) return "Male";
            else if (cmbPatientFemale.Checked) return "Female";
            else return "";
        }

        private void ClearGenderCheckboxes()
        {
            cmbPatientMale.Checked = false;
            cmbPatientFemale.Checked = false;
        }

        private void ClearFields()
        {
            txtPatientName.Clear();
            txtPatientAge.Clear();
            txtPatientAddress.Clear();
            txtPatientPhoneNumber.Clear();
            ClearGenderCheckboxes();
            return;
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtPatientName.Text) ||
                string.IsNullOrWhiteSpace(txtPatientAge.Text) ||
                string.IsNullOrWhiteSpace(txtPatientAddress.Text) ||
                string.IsNullOrWhiteSpace(txtPatientPhoneNumber.Text) ||
                string.IsNullOrEmpty(GetSelectedGender()))
            {
                MessageBox.Show("Please fill all fields and select gender.");
                return false;
            }

            if (!int.TryParse(txtPatientAge.Text, out int age) || age <= 0)
            {
                MessageBox.Show("Enter a valid age.");
                return false;
            }

            return true;
        }

        
        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs()) return;

                string sql = "INSERT INTO Patient (Name, Age, Address, PhoneNumber, Gender) " +
                             "VALUES (@Name, @Age, @Address, @Phone, @Gender)";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@Name", txtPatientName.Text.Trim()),
                    new SqlParameter("@Age", int.Parse(txtPatientAge.Text.Trim())),
                    new SqlParameter("@Address", txtPatientAddress.Text.Trim()),
                    new SqlParameter("@Phone", txtPatientPhoneNumber.Text.Trim()),
                    new SqlParameter("@Gender", GetSelectedGender())
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Patient added successfully!");
                  
                    LoadPatients();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Insert failed.");
                }
            }
            catch (Exception ex) { MessageBox.Show("Insert error: " + ex.Message); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (PatientGridView.CurrentRow == null || PatientGridView.CurrentRow.Cells[0].Value == null)
                {
                    MessageBox.Show("Please select a patient to update.");
                    return;
                }

              
                if (!ValidateInputs()) return;

               
                string id = PatientGridView.CurrentRow.Cells[0].Value.ToString();

                
                string sql = "UPDATE Patient SET Name=@Name, Age=@Age, Address=@Address, " +
                             "PhoneNumber=@Phone, Gender=@Gender WHERE PatientID=@Id";

                SqlParameter[] parameters = new SqlParameter[]
                {
            new SqlParameter("@Name", txtPatientName.Text.Trim()),
            new SqlParameter("@Age", int.Parse(txtPatientAge.Text.Trim())),
            new SqlParameter("@Address", txtPatientAddress.Text.Trim()),
            new SqlParameter("@Phone", txtPatientPhoneNumber.Text.Trim()),
            new SqlParameter("@Gender", GetSelectedGender()),
            new SqlParameter("@Id", int.Parse(id))
                };

                int result = this.Da.ExecuteUpdateQuery(sql, parameters);
                if (result > 0)
                {
                    MessageBox.Show("Patient updated successfully!");
                    LoadPatients();   
                    ClearFields();   
                }
                else
                {
                    MessageBox.Show("Update failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
           try
    {
        
        if (PatientGridView.CurrentRow == null || PatientGridView.CurrentRow.Cells[0].Value == null)
        {
            MessageBox.Show("Please select a patient to delete.");
            return;
        }

        
        DialogResult confirm = MessageBox.Show("Are you sure you want to delete this patient?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (confirm != DialogResult.Yes)
        {
            return;
        }

      
        string id = PatientGridView.CurrentRow.Cells[0].Value.ToString();

      
        string sql = "DELETE FROM Patient WHERE PatientID = @PatientID";
        SqlParameter[] parameters = new SqlParameter[]
        {
            new SqlParameter("@PatientID", int.Parse(id))
        };

       
        int result = this.Da.ExecuteUpdateQuery(sql, parameters);
        if (result > 0)
        {
            MessageBox.Show("Patient deleted successfully!");
          
            LoadPatients();      
            ClearFields();       
        }
        else
        {
            MessageBox.Show("Delete failed.");
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Delete error: " + ex.Message);
    }
        }

        private void PatientGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnInsert_Click_1(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {

        }

        private void PatientGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                DataGridViewRow row = PatientGridView.Rows[e.RowIndex];
                this.txtPatientName.Text = this.PatientGridView.CurrentRow.Cells[1].Value.ToString();
                this.txtPatientAge.Text = this.PatientGridView.CurrentRow.Cells[2].Value.ToString();
                this.txtPatientAddress.Text = this.PatientGridView.CurrentRow.Cells[4].Value.ToString();
                this.txtPatientPhoneNumber.Text = this.PatientGridView.CurrentRow.Cells[5].Value.ToString();

                string gender = this.PatientGridView.CurrentRow.Cells[3].Value.ToString();
                if (gender == "Male")
                {
                    cmbPatientMale.Checked = true;
                    cmbPatientFemale.Checked = false;
                }
                else if (gender == "Female")
                {
                    cmbPatientMale.Checked = false;
                    cmbPatientFemale.Checked = true;
                }
                else
                {
                    ClearGenderCheckboxes();
                }

            }
            catch (Exception ex) { MessageBox.Show("Select error: " + ex.Message); }
        }

        private void btnShow_Click_1(object sender, EventArgs e)
        {

        }

        
    }
}
